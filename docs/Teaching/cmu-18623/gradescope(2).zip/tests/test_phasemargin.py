import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_freq import get_phasemargin

class TestPhasemargin(unittest.TestCase):
    def setUp(self):
        pass

    @weight(3)
    @number("4.1")
    def test_phasemargin_70(self):
        """Test PM > 70"""
        self.pm = get_phasemargin("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        print("Phase margin = %.3f" % self.pm)
        self.assertGreaterEqual(self.pm, 70)

    @weight(3)
    @number("4.2")
    def test_phasemargin_70_vcm0p1(self):
        """Test PM > 70 (at VCM = 100m)"""
        self.pm_vcm0p1 = get_phasemargin("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        print("Phase margin = %.3f" % self.pm_vcm0p1)
        self.assertGreaterEqual(self.pm_vcm0p1, 70)

    @weight(3)
    @number("4.3")
    def test_phasemargin_70_vcmm0p1(self):
        """Test PM > 70 (at VCM = -100m)"""
        self.pm_vcmm0p1 = get_phasemargin("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        print("Phase margin = %.3f" % self.pm_vcmm0p1)
        self.assertGreaterEqual(self.pm_vcmm0p1, 70)

    @weight(1)
    @number("4.4")
    def test_phasemargin(self):
        """Calculate average PM"""
        pm = get_phasemargin("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        pm_vcm0p1 = get_phasemargin("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        pm_vcmm0p1 = get_phasemargin("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        print("Calculate average phase margin = %.2f" % ((pm + pm_vcm0p1 + pm_vcmm0p1) / 3))
