import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_power import get_instance_power

class TestPower(unittest.TestCase):
    def setUp(self):
        pass

    @weight(3)
    @number("9.1")
    def test_power_550u(self):
        """Test power < 550u"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        print("Power = %.1fu" % (power * 1e6))
        self.assertLessEqual(power, 550e-6)

    @weight(3)
    @number("9.2")
    def test_power_550u_vcm0p1(self):
        """Test power < 550u"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        print("Power = %.1fu" % (power * 1e6))
        self.assertLessEqual(power, 550e-6)

    @weight(3)
    @number("9.3")
    def test_power_550u_vcmm0p1(self):
        """Test power < 550u"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        print("Power = %.1fu" % (power * 1e6))
        self.assertLessEqual(power, 550e-6)

    @weight(1)
    @number("9.4")
    def test_power(self):
        """Calculate average power"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        power_vcm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        power_vcmm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        print("Calculate average power = %.1fu" % ((power + power_vcm0p1 + power_vcmm0p1) * 1e6 / 3))
