# -*- coding: utf-8 -*-

import unittest
import random
from gradescope_utils.autograder_utils.decorators import leaderboard
from util.get_area import get_area
from util.tran import get_clipped, get_slew_rate
from util.get_power import get_instance_power, get_value
from util.get_gain import get_gain
from util.get_area import get_ncomponents, get_area
from util.get_freq import get_unitfreq, get_phasemargin
import numpy as np


class TestLeaderboard(unittest.TestCase):
    def setUp(self):
        pass

    @leaderboard("FOM (m)")
    def test_leaderboard_fom(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        power_vcm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        power_vcmm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        olg = get_gain("sim_result_vcm0/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcm0p1 = get_gain("sim_result_vcm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcmm0p1 = get_gain("sim_result_vcmm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        offset = np.abs(get_value("sim_result_vcm0/dcOp.dc", net="offset"))
        offset_vcm0p1 = np.abs(get_value("sim_result_vcm0p1/dcOp.dc", net="offset"))
        offset_vcmm0p1 = np.abs(get_value("sim_result_vcmm0p1/dcOp.dc", net="offset"))
        ugf = get_unitfreq("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        ugf_vcm0p1 = get_unitfreq("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        ugf_vcmm0p1 = get_unitfreq("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        pm = get_phasemargin("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        pm_vcm0p1 = get_phasemargin("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        pm_vcmm0p1 = get_phasemargin("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc), min(yosc)
        _, yosc_vcm0p1 = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcm0p1, ymin_vcm0p1 = max(yosc_vcm0p1 - .1), min(yosc_vcm0p1 - .1)
        _, yosc_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcmm0p1, ymin_vcmm0p1 = max(yosc_vcmm0p1 + .1), min(yosc_vcmm0p1 + .1)

        tsrr, ysrr = get_clipped("sim_result_vcm0/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)
    
        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        tsrr_vcm0p1, ysrr_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcm0p1 = get_slew_rate(tsrr_vcm0p1, ysrr_vcm0p1, -.4, .4, 10, 90)
    
        tsrf_vcm0p1, ysrf_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcm0p1 = get_slew_rate(tsrf_vcm0p1, ysrf_vcm0p1, .4, -.4, 10, 90)

        tsrr_vcmm0p1, ysrr_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcmm0p1 = get_slew_rate(tsrr_vcmm0p1, ysrr_vcmm0p1, -.4, .4, 10, 90)
    
        tsrf_vcmm0p1, ysrf_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcmm0p1 = get_slew_rate(tsrf_vcmm0p1, ysrf_vcmm0p1, .4, -.4, 10, 90)

        completeness = int(power < 550e-6) + (olg > 600) + (np.abs(offset) < 1e-3) + (ugf > 100e6) + (pm > 70) + (ymax > .5) + (ymin < -.5) + (slew_rising > 100e6) + (slew_falling < -100e6)
        completeness_vcm0p1 = int(power_vcm0p1 < 550e-6) + (olg_vcm0p1 > 600) + (np.abs(offset_vcm0p1) < 1e-3) + (ugf_vcm0p1 > 100e6) + (pm_vcm0p1 > 70) + (ymax_vcm0p1 > .5) + (ymin_vcm0p1 < -.5) + (slew_rising_vcm0p1 > 100e6) + (slew_falling_vcm0p1 < -100e6)
        completeness_vcmm0p1 = int(power_vcmm0p1 < 550e-6) + (olg_vcmm0p1 > 600) + (np.abs(offset_vcmm0p1) < 1e-3) + (ugf_vcmm0p1 > 100e6) + (pm_vcmm0p1 > 70) + (ymax_vcmm0p1 > .5) + (ymin_vcmm0p1 < -.5) + (slew_rising_vcmm0p1 > 100e6) + (slew_falling_vcmm0p1 < -100e6)
        yield_avg = (completeness + completeness_vcm0p1 + completeness_vcmm0p1) / 27

        area = get_area('merged_vcm0.scs', 'opamp')
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        power_vcm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        power_vcmm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        power_avg = np.array([power, power_vcm0p1, power_vcmm0p1]).mean()
        fom = yield_avg / (area * power_avg)
        set_leaderboard_value(fom // 1e-1 * 1e-1)

    @leaderboard("Yield (Fake)")
    def test_leaderboard_yield(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        power_vcm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        power_vcmm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        olg = get_gain("sim_result_vcm0/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcm0p1 = get_gain("sim_result_vcm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcmm0p1 = get_gain("sim_result_vcmm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        offset = np.abs(get_value("sim_result_vcm0/dcOp.dc", net="offset"))
        offset_vcm0p1 = np.abs(get_value("sim_result_vcm0p1/dcOp.dc", net="offset"))
        offset_vcmm0p1 = np.abs(get_value("sim_result_vcmm0p1/dcOp.dc", net="offset"))
        ugf = get_unitfreq("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        ugf_vcm0p1 = get_unitfreq("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        ugf_vcmm0p1 = get_unitfreq("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        pm = get_phasemargin("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        pm_vcm0p1 = get_phasemargin("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        pm_vcmm0p1 = get_phasemargin("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc), min(yosc)
        _, yosc_vcm0p1 = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcm0p1, ymin_vcm0p1 = max(yosc_vcm0p1 - .1), min(yosc_vcm0p1 - .1)
        _, yosc_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcmm0p1, ymin_vcmm0p1 = max(yosc_vcmm0p1 + .1), min(yosc_vcmm0p1 + .1)

        tsrr, ysrr = get_clipped("sim_result_vcm0/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)
    
        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        tsrr_vcm0p1, ysrr_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcm0p1 = get_slew_rate(tsrr_vcm0p1, ysrr_vcm0p1, -.4, .4, 10, 90)
    
        tsrf_vcm0p1, ysrf_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcm0p1 = get_slew_rate(tsrf_vcm0p1, ysrf_vcm0p1, .4, -.4, 10, 90)

        tsrr_vcmm0p1, ysrr_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcmm0p1 = get_slew_rate(tsrr_vcmm0p1, ysrr_vcmm0p1, -.4, .4, 10, 90)
    
        tsrf_vcmm0p1, ysrf_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcmm0p1 = get_slew_rate(tsrf_vcmm0p1, ysrf_vcmm0p1, .4, -.4, 10, 90)

        completeness = int(power < 550e-6) + (olg > 600) + (np.abs(offset) < 1e-3) + (ugf > 100e6) + (pm > 70) + (ymax > .5) + (ymin < -.5) + (slew_rising > 100e6) + (slew_falling < -100e6)
        completeness_vcm0p1 = int(power_vcm0p1 < 550e-6) + (olg_vcm0p1 > 600) + (np.abs(offset_vcm0p1) < 1e-3) + (ugf_vcm0p1 > 100e6) + (pm_vcm0p1 > 70) + (ymax_vcm0p1 > .5) + (ymin_vcm0p1 < -.5) + (slew_rising_vcm0p1 > 100e6) + (slew_falling_vcm0p1 < -100e6)
        completeness_vcmm0p1 = int(power_vcmm0p1 < 550e-6) + (olg_vcmm0p1 > 600) + (np.abs(offset_vcmm0p1) < 1e-3) + (ugf_vcmm0p1 > 100e6) + (pm_vcmm0p1 > 70) + (ymax_vcmm0p1 > .5) + (ymin_vcmm0p1 < -.5) + (slew_rising_vcmm0p1 > 100e6) + (slew_falling_vcmm0p1 < -100e6)
        set_leaderboard_value(((completeness + completeness_vcm0p1 + completeness_vcmm0p1 + .1) / 27) // .01 * .01)

    @leaderboard("Power (uW)")
    def test_leaderboard_power(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        power_vcm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        power_vcmm0p1 = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        power_avg = np.array([power, power_vcm0p1, power_vcmm0p1]).mean()
        set_leaderboard_value(int(power_avg * 1e6))

    @leaderboard("OLG")
    def test_leaderboard_olg(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        olg = get_gain("sim_result_vcm0/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcm0p1 = get_gain("sim_result_vcm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcmm0p1 = get_gain("sim_result_vcmm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_avg = (olg + olg_vcm0p1 + olg_vcmm0p1) / 3
        set_leaderboard_value(olg_avg // 10 * 10)

    @leaderboard("Offset (uV)")
    def test_leaderboard_offset(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        offset = np.abs(get_value("sim_result_vcm0/dcOp.dc", net="offset"))
        offset_vcm0p1 = np.abs(get_value("sim_result_vcm0p1/dcOp.dc", net="offset"))
        offset_vcmm0p1 = np.abs(get_value("sim_result_vcmm0p1/dcOp.dc", net="offset"))
        offset_avg = (offset + offset_vcm0p1 + offset_vcmm0p1) / 3
        set_leaderboard_value(int(offset_avg * 1e6))

    @leaderboard("UGF (MHz)")
    def test_leaderboard_ugf(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        ugf = get_unitfreq("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        ugf_vcm0p1 = get_unitfreq("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        ugf_vcmm0p1 = get_unitfreq("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        print("UGF = ", ugf)
        ugf_avg = (ugf + ugf_vcm0p1 + ugf_vcmm0p1) / 3
        set_leaderboard_value(int(ugf_avg * 1e-6))

    @leaderboard("PM")
    def test_leaderboard_phasemargin(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        pm = get_phasemargin("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        pm_vcm0p1 = get_phasemargin("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        pm_vcmm0p1 = get_phasemargin("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        # pm = def get_phasemargin(fname, net, fmin=1, fmax=1e12, nfreq=500, net_in=None):
        # power = get_power("sim_result/dp1_dc.dc") // 1e-6
        pm_avg = (pm + pm_vcm0p1 + pm_vcmm0p1) / 3

        set_leaderboard_value(int(pm_avg))

    @leaderboard("Area (um2)")
    def test_leaderboard_area(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        area = get_area('merged_vcm0.scs', 'opamp')
        set_leaderboard_value(int(area))

    @leaderboard("# of elem")
    def test_leaderboard_ncomp(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        ncomp = get_ncomponents('merged_vcm0.scs', 'opamp')
        set_leaderboard_value(ncomp)

    @leaderboard("Vpeak")
    def test_leaderboard_peak(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc), min(yosc)
        _, yosc_vcm0p1 = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcm0p1, ymin_vcm0p1 = max(yosc_vcm0p1 - .1), min(yosc_vcm0p1 - .1)
        _, yosc_vcmm0p1 = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcmm0p1, ymin_vcmm0p1 = max(yosc_vcmm0p1 + .1), min(yosc_vcmm0p1 + .1)
    
        peak = np.abs([ymax, ymax_vcm0p1, ymax_vcmm0p1, ymin, ymin_vcm0p1, ymin_vcmm0p1]).mean()
        set_leaderboard_value(int(peak * 1e3))

    @leaderboard("Slew")
    def test_leaderboard_slew(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        tsrr, ysrr = get_clipped("sim_result_vcm0/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)
    
        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        tsrr_vcm0p1, ysrr_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcm0p1 = get_slew_rate(tsrr_vcm0p1, ysrr_vcm0p1, -.4, .4, 10, 90)
    
        tsrf_vcm0p1, ysrf_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcm0p1 = get_slew_rate(tsrf_vcm0p1, ysrf_vcm0p1, .4, -.4, 10, 90)

        tsrr_vcmm0p1, ysrr_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcmm0p1 = get_slew_rate(tsrr_vcmm0p1, ysrr_vcmm0p1, -.4, .4, 10, 90)
    
        tsrf_vcmm0p1, ysrf_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcmm0p1 = get_slew_rate(tsrf_vcmm0p1, ysrf_vcmm0p1, .4, -.4, 10, 90)

        slew = np.abs([slew_rising, slew_falling, slew_rising_vcm0p1, slew_falling_vcm0p1, slew_rising_vcmm0p1, slew_falling_vcmm0p1]).mean()
        set_leaderboard_value(int(slew * 1e-6))

#     @leaderboard("accuracy")
#     def test_leaderboard_float(self, set_leaderboard_value=None):
#         """Sets a leaderboard value"""
#         set_leaderboard_value(round(random.uniform(50, 100), 2))
# 
#     @leaderboard("stars")
#     def test_string(self, set_leaderboard_value=None):
#         """Sets a leaderboard value"""
#         set_leaderboard_value("🌟" * random.randint(0, 10))
# 
#     @leaderboard("time", "asc")
#     def test_another(self, set_leaderboard_value=None):
#         """Sets a leaderboard value that's sorted ascending (lower is better)"""
#         set_leaderboard_value(round(random.gauss(7, 3), 2))
