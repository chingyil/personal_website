import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_freq import get_unitfreq

class TestBandwidth(unittest.TestCase):
    def setUp(self):
        self.ugf_mhz = get_unitfreq("sim_result_vcm0/ac.ac", net="vout2", net_in="net021") * 1e-6
        self.ugf_mhz_vcm0p1 = get_unitfreq("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021") * 1e-6
        self.ugf_mhz_vcmm0p1 = get_unitfreq("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021") * 1e-6

    @weight(3)
    @number("3.1")
    def test_ugf_10M(self):
        """Test UGF > 100M"""
        print("UGF = %.2fMHz" % self.ugf_mhz)
        self.assertGreaterEqual(self.ugf_mhz, 100)

    @weight(3)
    @number("3.2")
    def test_ugf_10M_vcm0p1(self):
        """Test UGF > 100M (at VCM = 100m)"""
        print("UGF = %.2fMHz" % self.ugf_mhz_vcm0p1)
        self.assertGreaterEqual(self.ugf_mhz_vcm0p1, 100)

    @weight(3)
    @number("3.3")
    def test_ugf_10M_vcmm0p1(self):
        """Test UGF > 100M (at VCM = -100m)"""
        print("UGF = %.2fMHz" % self.ugf_mhz_vcmm0p1)
        self.assertGreaterEqual(self.ugf_mhz_vcmm0p1, 100)

    @weight(1)
    @number("3.4")
    def test_ugf_10M_average(self):
        """Calculate average UGF"""
        print("UGF = %.2fMHz" % ((self.ugf_mhz + self.ugf_mhz_vcm0p1 + self.ugf_mhz_vcmm0p1) / 3))
