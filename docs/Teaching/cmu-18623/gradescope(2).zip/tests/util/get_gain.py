"""
Description: Evaluate a psf ascii waveform
Author: Ching-Yi Lin (chingyil@andrew.cmu.edu)
Date Modified: Oct 27, 2023
"""

import re
import numpy as np
from psf_utils import PSF
from inform import Error, display

def get_gain(fname, net_input="I4:sink", net_output="out", unit_input='A', unit_output='V', net_input_diff=None):

    psf = PSF(fname)

    iin_unit = psf.get_signal(net_input).type.units
    vout_unit = psf.get_signal(net_output).type.units
    assert iin_unit == unit_input and vout_unit == unit_output

    if net_input_diff is None:
        iin = np.real(psf.get_signal(net_input).ordinate)
    elif net_input_diff is not None:
        iin = np.real(psf.get_signal(net_input).ordinate - psf.get_signal(net_input_diff).ordinate)
    iin_lfreq = iin[0]
    print("Input = %.3f%s" % (iin_lfreq, unit_input))
    vout = np.abs(psf.get_signal(net_output).ordinate)
    vout_lfreq = vout[0]
    print("Output = %.3f%s" % (vout_lfreq, unit_output))
    gain = vout_lfreq / iin_lfreq
    print("Gain = ", gain)
    return gain
