"""
Description: Evaluate a psf ascii waveform
Author: Ching-Yi Lin (chingyil@andrew.cmu.edu)
Date Modified: Oct 27, 2023
"""

import re
import numpy as np
from psf_utils import PSF
from inform import Error, display

def get_clipped(fname, net, tmin, tmax):

    psf = PSF(fname)

    t = psf.get_sweep().abscissa
    tmask = (t > tmin) * (t < tmax)
    y = psf.get_signal(net).ordinate

    return t[tmask], y[tmask]

def cross(t, y, val):
    diff = y - val
    tcross = t[:-1][(diff[1:] * diff[:-1]) < 0]
    if (diff[1:] * diff[:-1]).min() >= 0:
        import pdb; pdb.set_trace()
    if len(tcross) == 0:
        import pdb; pdb.set_trace()
    return tcross.min()

def get_slew_rate(t, y, ystart, yend, plow, phigh):
    y0 = (1 - plow / 100) * ystart + (plow / 100) * yend
    y1 = (1 - phigh / 100) * ystart + (phigh / 100) * yend
    t0 = cross(t, y, y0)
    t1 = cross(t, y, y1)
    slope = (y1 - y0) / (t1 - t0)
    return slope
