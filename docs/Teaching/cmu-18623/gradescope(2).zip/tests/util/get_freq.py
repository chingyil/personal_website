"""
Description: Evaluate a psf ascii waveform
Author: Ching-Yi Lin (chingyil@andrew.cmu.edu)
Date Modified: Oct 27, 2023
"""

import re
import numpy as np
from psf_utils import PSF
from inform import Error, display

def get_freq(fname, net="out", freq_detailed=None, net_in=None):

    psf = PSF(fname)
    freq = psf.get_sweep().abscissa

    if net_in is None:
        signal = np.abs(psf.get_signal(net).ordinate)
    else:
        signal = np.abs(psf.get_signal(net).ordinate / psf.get_signal(net_in).ordinate)
    signal_detailed = np.interp(freq_detailed, freq, signal)

    return signal_detailed

def get_phase(fname, net="out", freq_detailed=None, net_in=None):

    psf = PSF(fname)
    freq = psf.get_sweep().abscissa

    if net_in is None:
        signal = psf.get_signal(net).ordinate
    else:
        signal = psf.get_signal(net).ordinate / psf.get_signal(net_in).ordinate
    signal_detailed = np.interp(freq_detailed, freq, signal)

    return np.angle(signal_detailed, deg=True)

def get_3dbfreq(fname, net="out", nfreq=500, net_in=None, fmin=1, fmax=1e12):

    psf = PSF(fname)

    freq_detailed = np.logspace(np.log10(fmin), np.log10(fmax), num=nfreq)

    signal_detailed = get_freq(fname, net, freq_detailed, net_in=net_in)
    freq_3db = freq_detailed[signal_detailed < signal_lfreq * np.sqrt(0.5)][0]
    return freq_3db

def get_unitfreq(fname, net="out", nfreq=500, net_in=None, fmin=1, fmax=1e12):
    psf = PSF(fname)

    freq = psf.get_sweep().abscissa
    freq_detailed = np.logspace(np.log10(fmin), np.log10(fmax), num=nfreq)

    signal_detailed = get_freq(fname, net, freq_detailed, net_in=net_in)
    ugf = freq_detailed[signal_detailed < 1][0]
    return ugf

def get_phasemargin(fname, net, fmin=1, fmax=1e12, nfreq=500, net_in=None):
    psf = PSF(fname)

    freq = psf.get_sweep().abscissa
    freq_detailed = np.logspace(np.log10(fmin), np.log10(fmax), num=nfreq)

    phase_detailed = get_phase(fname, net, freq_detailed, net_in=net_in)
    phase_at_dc = phase_detailed[0]
    ugf = get_unitfreq(fname, net, nfreq, net_in, fmin, fmax)
    phase_at_ugf = np.interp([ugf], freq_detailed, phase_detailed)[0]
    phase_margin = phase_at_ugf - (phase_at_dc - 180)
    print("phase = ", phase_at_dc, phase_at_ugf, phase_margin)
    return phase_margin

def get_pbpeak(fname, net="out"):

    psf = PSF(fname)

    signal = np.abs(psf.get_signal(net).ordinate)
    signal_lfreq = signal[0]
    passband = signal.max() / signal_lfreq
    passband_db = 20 * np.log10(passband)

    return passband_db
