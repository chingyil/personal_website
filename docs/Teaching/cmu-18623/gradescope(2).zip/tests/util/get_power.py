"""
Description: Evaluate a psf ascii waveform
Author: Ching-Yi Lin (chingyil@andrew.cmu.edu)
Date Modified: Oct 27, 2023
"""

import re
import numpy as np
from psf_utils import PSF
from inform import Error, display

# def get_freq(fname, net="out", freq_detailed=None, net_in=None):
# 
#     psf = PSF(fname)
#     freq = psf.get_sweep().abscissa
# 
#     if net_in is None:
#         signal = np.abs(psf.get_signal(net).ordinate)
#     else:
#         signal = np.abs(psf.get_signal(net).ordinate / psf.get_signal(net_in).ordinate)
#     signal_detailed = np.interp(freq_detailed, freq, signal)
# 
#     return signal_detailed
# 
# def get_phase(fname, net="out", freq_detailed=None, net_in=None):
# 
#     psf = PSF(fname)
#     freq = psf.get_sweep().abscissa
# 
#     if net_in is None:
#         signal = psf.get_signal(net).ordinate
#     else:
#         signal = psf.get_signal(net).ordinate / psf.get_signal(net_in).ordinate
#     signal_detailed = np.interp(freq_detailed, freq, signal)
# 
#     return np.angle(signal_detailed, deg=True)
# 
# def get_3dbfreq(fname, net="out", nfreq=500, net_in=None, fmin=1, fmax=1e12):
# 
#     psf = PSF(fname)
# 
#     freq_detailed = np.logspace(np.log10(fmin), np.log10(fmax), num=nfreq)
# 
#     signal_detailed = get_freq(fname, net, freq_detailed, net_in=net_in)
#     freq_3db = freq_detailed[signal_detailed < signal_lfreq * np.sqrt(0.5)][0]
#     return freq_3db
# 
# def get_unitfreq(fname, net="out", nfreq=500, net_in=None, fmin=1, fmax=1e12):
#     psf = PSF(fname)
# 
#     freq = psf.get_sweep().abscissa
#     freq_detailed = np.logspace(np.log10(fmin), np.log10(fmax), num=nfreq)
# 
#     signal_detailed = get_freq(fname, net, freq_detailed, net_in=net_in)
#     ugf = freq_detailed[signal_detailed < 1][0]
#     return ugf
# 
# def get_phasemargin(fname, net, fmin=1, fmax=1e12, nfreq=500, net_in=None):
#     psf = PSF(fname)
# 
#     freq = psf.get_sweep().abscissa
#     freq_detailed = np.logspace(np.log10(fmin), np.log10(fmax), num=nfreq)
# 
#     phase_detailed = get_phase(fname, net, freq_detailed, net_in=net_in)
#     phase_at_dc = phase_detailed[0]
#     ugf = get_unitfreq(fname, net, nfreq, net_in, fmin, fmax)
#     phase_at_ugf = np.interp([ugf], freq_detailed, phase_detailed)[0]
#     phase_margin = phase_at_ugf - (phase_at_dc - 180)
#     print("phase = ", phase_at_dc, phase_at_ugf, phase_margin)
#     return phase_margin
# 
# def get_pbpeak(fname, net="out"):
# 
#     psf = PSF(fname)
# 
#     signal = np.abs(psf.get_signal(net).ordinate)
#     signal_lfreq = signal[0]
#     passband = signal.max() / signal_lfreq
#     passband_db = 20 * np.log10(passband)
# 
#     return passband_db

from util.get_gain import get_gain
from util.get_area import get_ncomponents, get_area
from util.get_freq import get_unitfreq, get_phasemargin

def get_value(fname, net="I4:sink", unit='A'):

    psf = PSF(fname)

    unit = psf.get_signal(net).type.units
    value = psf.get_signal(net).ordinate
    return value

def get_args(fname, device, instance_name):
    with open(fname) as f:
        line = [l for l in f.readlines() if device in l and instance_name in l][0]
        idx_start = line.index("(") + 1
        idx_end = line.index(")")
        print(line[idx_start:idx_end])
        args = line[idx_start:idx_end].split(" ")
        print(args)
    return args

def get_instance_power(fname_netlist, fname_dc, device, instance_name):
    nets = get_args(fname_netlist, device, instance_name)
    power_total = 0
    for idx, net in enumerate(nets):
        v = get_value(fname_dc, net, unit='V')
        current = get_value(fname_dc, "%s:%d" % (instance_name, idx + 1), unit='A')
        power_local = v * current
        power_total += power_local
    print("power_total = ", power_total)
    return power_total

# 
# def get_clipped(fname, net, tmin, tmax):
# 
#     psf = PSF(fname)
# 
#     t = psf.get_sweep().abscissa
#     tmask = (t > tmin) * (t < tmax)
#     y = psf.get_signal(net).ordinate
# 
#     return t[tmask], y[tmask]
# 
# def cross(t, y, val):
#     diff = y - val
#     print("diff = ", diff)
#     tcross = t[:-1][(diff[1:] * diff[:-1]) < 0]
#     print("tcross = ", tcross)
#     if (diff[1:] * diff[:-1]).min() >= 0:
#         import pdb; pdb.set_trace()
#     if len(tcross) == 0:
#         import pdb; pdb.set_trace()
#     return tcross.min()
# 
# def get_slew_rate(t, y, ystart, yend, plow, phigh):
#     y0 = (1 - plow / 100) * ystart + (plow / 100) * yend
#     y1 = (1 - phigh / 100) * ystart + (phigh / 100) * yend
#     print("y0 = ", y0)
#     print("y1 = ", y1)
#     print("t = ", t)
#     print("y = ", y)
#     t0 = cross(t, y, y0)
#     t1 = cross(t, y, y1)
#     print(t0, y0)
#     print(t1, y1)
#     slope = (y1 - y0) / (t1 - t0)
#     print("slope = ", slope)
#     return slope

from util.tran import get_clipped, get_slew_rate
from util.get_power import get_instance_power

def main():
    ncomp = get_ncomponents('opamp.scs', 'opamp')
    area = get_area('opamp.scs', 'opamp')
    
    olg = get_gain("sim_result/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
    print("OLG = ", olg)

    offset = get_value("sim_result/dcOp.dc", net="offset")
    print("offset = ", offset)

    ugf = get_unitfreq("sim_result/ac.ac", net="vout2", net_in="net021")
    print("UGF = ", ugf)

    pm = get_phasemargin("sim_result/ac.ac", net="vout2", net_in="net021")
    print("PM = %.2f" % pm)
    # pm = def get_phasemargin(fname, net, fmin=1, fmax=1e12, nfreq=500, net_in=None):

    nets = get_instance_power('test_opamp.scs', 'sim_result/dcOp.dc', 'opamp', 'I20')

    _, yosc = get_clipped("sim_result/tranPeak.tran", "vout3", 9.6e-6, 1e-5)
    ymax, ymin = max(yosc), min(yosc)

    tsrr, ysrr = get_clipped("sim_result/tranSRR.tran", "vout3", 1.98e-6, 2.04e-6)
    slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)

    tsrf, ysrf = get_clipped("sim_result/tranSRF.tran", "vout3", 2.98e-6, 3.04e-6)
    slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

    import pdb; pdb.set_trace()

    gain_k = get_gain('sim_result/dp1_ac.ac') / 1e3
    rin = get_rin('sim_result/dp1_ac.ac')
    bw_M = get_3dbfreq('sim_result/dp1_ac.ac') / 1e6
    pbpeak_db = get_pbpeak('sim_result/dp1_ac.ac')
    oswing_m = get_swing('sim_result/dp1_tran.tran.tran', 'out') * 1e3
    power_m = get_power('sim_result/dp1_dc.dc') * 1e3

    print("Gain = %.2fk" % gain_k)
    print("rin = %.2f" % rin)
    print("Bandwidth = %.2fM" % bw_M)
    print("Passband peak = %.2fdB" % pbpeak_db)
    print("Output swing = %.2fmV" % oswing_m)
    print("power_m = %.2fmW" % power_m)
    print("area = %.2fum2" % area)
    print("# of components = %d" % ncomp)

if __name__ == "__main__":
    main()

