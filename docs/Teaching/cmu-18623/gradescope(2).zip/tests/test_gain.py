import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_gain import get_gain

class TestGain(unittest.TestCase):
    def setUp(self):
        pass

    @weight(3)
    @number("1.1")
    def test_gain_600(self):
        """Test OLG > 10K"""
        olg = get_gain("sim_result_vcm0/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        print("OLG = %d" % olg)
        self.assertGreaterEqual(olg, 600)

    @weight(3)
    @number("1.2")
    def test_gain_600_vcm0p1(self):
        """Test OLG > 10K (at VCM = 100m)"""
        olg_vcm0p1 = get_gain("sim_result_vcm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        print("OLG = %d" % olg_vcm0p1)
        self.assertGreaterEqual(olg_vcm0p1, 600)

    @weight(3)
    @number("1.3")
    def test_gain_600_vcmm0p1(self):
        """Test OLG > 10K (at VCM = -100m)"""
        olg_vcmm0p1 = get_gain("sim_result_vcmm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        print("OLG = %d" % olg_vcmm0p1)
        self.assertGreaterEqual(olg_vcmm0p1, 600)

    @weight(1)
    @number("1.4")
    def test_gain_avg(self):
        """Calculate average OLG"""
        olg = get_gain("sim_result_vcm0/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcm0p1 = get_gain("sim_result_vcm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        olg_vcmm0p1 = get_gain("sim_result_vcmm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        print("OLG average = %d" % (olg + olg_vcm0p1 + olg_vcmm0p1))
