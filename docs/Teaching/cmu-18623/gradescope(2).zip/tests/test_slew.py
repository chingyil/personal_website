import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.tran import get_clipped, get_slew_rate

class TestSlew(unittest.TestCase):
    def setUp(self):
        pass

    @weight(3)
    @number("7.1")
    def test_slewpos_100M(self):
        """Test pos slew > 100M"""
        tsrr, ysrr = get_clipped("sim_result_vcm0/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)
        print("Slew = %.1fM" % (slew_rising * 1e-6))
        self.assertGreaterEqual(slew_rising, 100e6)

    @weight(3)
    @number("8.1")
    def test_slewneg_100M(self):
        """Test neg slew > 100M"""
        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)
        print("Slew = %.1fM" % (slew_falling * 1e-6))
        self.assertLessEqual(slew_falling, -100e6)

    @weight(3)
    @number("7.2")
    def test_slewpos_100M_vcm0p1(self):
        """Test pos slew > 100M (at VCM = 100m)"""
        tsrr, ysrr = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)
        print("Slew = %.1fM" % (slew_rising * 1e-6))
        self.assertGreaterEqual(slew_rising, 100e6)

    @weight(3)
    @number("8.2")
    def test_slewneg_100M_vcm0p1(self):
        """Test neg slew > 100M (at VCM = 100m)"""
        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)
        print("Slew = %.1fM" % (slew_falling * 1e-6))
        self.assertLessEqual(slew_falling, -100e6)

    @weight(3)
    @number("7.3")
    def test_slewpos_100M_vcmm0p1(self):
        """Test pos slew > 100M (at VCM = -100m)"""
        tsrr, ysrr = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)
        print("Slew = %.1fM" % (slew_rising * 1e-6))
        self.assertGreaterEqual(slew_rising, 100e6)

    @weight(3)
    @number("8.3")
    def test_slewneg_100M_vcmm0p1(self):
        """Test neg slew > 100M (at VCM = -100m)"""
        tsrf, ysrf = get_clipped("sim_result_vcmm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)
        print("Slew = %.1fM" % (slew_falling * 1e-6))
        self.assertLessEqual(slew_falling, -100e6)


    @weight(2)
    @number("8.4")
    def test_slewneg(self):
        """Calculate average slew"""
        tsrr, ysrr = get_clipped("sim_result_vcm0/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)

        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        tsrr_vcm0p1, ysrr_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcm0p1 = get_slew_rate(tsrr_vcm0p1, ysrr_vcm0p1, -.4, .4, 10, 90)

        tsrf_vcm0p1, ysrf_vcm0p1 = get_clipped("sim_result_vcm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcm0p1 = get_slew_rate(tsrf_vcm0p1, ysrf_vcm0p1, .4, -.4, 10, 90)

        tsrr_vcmm0p1, ysrr_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising_vcmm0p1 = get_slew_rate(tsrr_vcmm0p1, ysrr_vcmm0p1, -.4, .4, 10, 90)

        tsrf_vcmm0p1, ysrf_vcmm0p1 = get_clipped("sim_result_vcmm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling_vcmm0p1 = get_slew_rate(tsrf_vcmm0p1, ysrf_vcmm0p1, .4, -.4, 10, 90)

        slew = np.abs([slew_rising, slew_falling, slew_rising_vcm0p1, slew_falling_vcm0p1, slew_rising_vcmm0p1, slew_falling_vcmm0p1]).mean()
        print("Slew average = %.1fM" % (slew * 1e-6))
