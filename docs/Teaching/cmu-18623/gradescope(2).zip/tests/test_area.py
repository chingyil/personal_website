import re
import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_area import get_area

class TestArea(unittest.TestCase):
    def setUp(self):
        self.area = get_area("merged_vcm0.scs", 'opamp')

    @weight(4)
    @number("0.1")
    def test_valid_components(self):
        """Test all components are valid"""
        print("Component check bypassed here. We will check by ourselves")
        self.assertGreaterEqual(self.area, 0)
