import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.tran import get_clipped

class TestVoutPeak(unittest.TestCase):
    def setUp(self):
        pass

    @weight(3)
    @number("5.1")
    def test_voutneg_500m(self):
        """Test Vout < -500m"""
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        print("Peak = %.1fm ~ %.1fm" % (max(yosc) * 1000, min(yosc) * 1000))
        self.assertLessEqual(min(yosc), -.5)

    @weight(3)
    @number("6.1")
    def test_voutpos_500m(self):
        """Test Vout > 500m"""
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        print("Peak = %.1fm ~ %.1fm" % (max(yosc) * 1000, min(yosc) * 1000))
        self.assertGreaterEqual(max(yosc), .5)

    @weight(3)
    @number("5.2")
    def test_voutneg_500m_vcm0p1(self):
        """Test Vout < -500m (at VCM = 100m)"""
        _, yosc_raw = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        yosc = yosc_raw - .1
        print("Peak = %.1fm ~ %.1fm" % (max(yosc) * 1000, min(yosc) * 1000))
        self.assertLessEqual(min(yosc), -.5)

    @weight(3)
    @number("6.2")
    def test_voutpos_500m_vcm0p1(self):
        """Test Vout > 500m (at VCM = 100m)"""
        _, yosc_raw = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        yosc = yosc_raw - .1
        print("Peak = %.1fm ~ %.1fm" % (max(yosc) * 1000, min(yosc) * 1000))
        self.assertGreaterEqual(max(yosc), .5)

    @weight(3)
    @number("5.3")
    def test_voutneg_500m_vcmm0p1(self):
        """Test Vout < -500m (at VCM = -100m)"""
        _, yosc_raw = get_clipped("sim_result_vcmm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        yosc = yosc_raw + .1
        print("Peak = %.1fm ~ %.1fm" % (max(yosc) * 1000, min(yosc) * 1000))
        self.assertLessEqual(min(yosc), -.5)

    @weight(3)
    @number("6.3")
    def test_voutpos_500m_vcmm0p1(self):
        """Test Vout > 500m (at VCM = -100m)"""
        _, yosc_raw = get_clipped("sim_result_vcmm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        yosc = yosc_raw + .1
        print("Peak = %.1fm ~ %.1fm" % (max(yosc) * 1000, min(yosc) * 1000))
        self.assertGreaterEqual(max(yosc), .5)

    @weight(2)
    @number("6.4")
    def test_vout(self):

        """Calculate average Vpeak"""
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc), min(yosc)
        _, yosc_vcm0p1 = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcm0p1, ymin_vcm0p1 = max(yosc_vcm0p1 - .1), min(yosc_vcm0p1 - .1)
        _, yosc_vcmm0p1 = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax_vcmm0p1, ymin_vcmm0p1 = max(yosc_vcmm0p1 + .1), min(yosc_vcmm0p1 + .1)

        peak = np.abs([ymax, ymax_vcm0p1, ymax_vcmm0p1, ymin, ymin_vcm0p1, ymin_vcmm0p1]).mean()
        print("Calculate average vpeak = %.2f" % (peak * 1e3))

