import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_power import get_instance_power
from util.get_area import get_area
from util.tran import get_clipped, get_slew_rate
from util.get_power import get_instance_power, get_value
from util.get_gain import get_gain
from util.get_area import get_ncomponents, get_area
from util.get_freq import get_unitfreq, get_phasemargin

class TestYield(unittest.TestCase):
    def setUp(self):
        pass

    @weight(2)
    @number("10.1")
    def test_yield(self):
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0/dcOp.dc', 'opamp', 'I20')
        olg = get_gain("sim_result_vcm0/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        offset = np.abs(get_value("sim_result_vcm0/dcOp.dc", net="offset"))
        ugf = get_unitfreq("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        pm = get_phasemargin("sim_result_vcm0/ac.ac", net="vout2", net_in="net021")
        _, yosc = get_clipped("sim_result_vcm0/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc), min(yosc)

        tsrr, ysrr = get_clipped("sim_result_vcm0/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)

        tsrf, ysrf = get_clipped("sim_result_vcm0/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        completeness = 0
        if power < 550e-6:
            completeness += 1
            print("Power check passed (%d%%)" % (completeness * 100 / 9))
        if olg > 600:
            completeness += 1
            print("OLG check passed (%d%%)" % (completeness * 100 / 9))
        if np.abs(offset) < 1e-3:
            completeness += 1
            print("offset check passed (%d%%)" % (completeness * 100 / 9))
        if ugf > 100e6:
            completeness += 1
            print("UGF check passed (%d%%)" % (completeness * 100 / 9))
        if pm > 70:
            completeness += 1
            print("PM check passed (%d%%)" % (completeness * 100 / 9))
        if slew_rising > 100e6:
            completeness += 1
            print("Rising slew check passed (%d%%)" % (completeness * 100 / 9))
        if slew_falling < -100e6:
            completeness += 1
            print("Falling slew check passed (%d%%)" % (completeness * 100 / 9))
        if ymax > .5:
            completeness += 1
            print("Vpeak pos check passed (%d%%)" % (completeness * 100 / 9))
        if ymin < -.5:
            completeness += 1
            print("Vpeak pos check passed (%d%%)" % (completeness * 100 / 9))
        print("Yield (fake) = %.1f" % (completeness / 9))
        self.assertGreaterEqual(completeness, 9)

    @weight(2)
    @number("10.2")
    def test_yield_vcm0p1(self):
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcm0p1/dcOp.dc', 'opamp', 'I20')
        olg = get_gain("sim_result_vcm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        offset = np.abs(get_value("sim_result_vcm0p1/dcOp.dc", net="offset"))
        ugf = get_unitfreq("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        pm = get_phasemargin("sim_result_vcm0p1/ac.ac", net="vout2", net_in="net021")
        _, yosc = get_clipped("sim_result_vcm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc - .1), min(yosc - .1)

        tsrr, ysrr = get_clipped("sim_result_vcm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)

        tsrf, ysrf = get_clipped("sim_result_vcm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        completeness = 0
        if power < 550e-6:
            completeness += 1
            print("Power check passed (%d%%)" % (completeness * 100 / 9))
        if olg > 600:
            completeness += 1
            print("OLG check passed (%d%%)" % (completeness * 100 / 9))
        if np.abs(offset) < 1e-3:
            completeness += 1
            print("offset check passed (%d%%)" % (completeness * 100 / 9))
        if ugf > 100e6:
            completeness += 1
            print("UGF check passed (%d%%)" % (completeness * 100 / 9))
        if pm > 70:
            completeness += 1
            print("PM check passed (%d%%)" % (completeness * 100 / 9))
        if slew_rising > 100e6:
            completeness += 1
            print("Rising slew check passed (%d%%)" % (completeness * 100 / 9))
        if slew_falling < -100e6:
            completeness += 1
            print("Falling slew check passed (%d%%)" % (completeness * 100 / 9))
        if ymax > .5:
            completeness += 1
            print("Vpeak pos check passed (%d%%)" % (completeness * 100 / 9))
        if ymin < -.5:
            completeness += 1
            print("Vpeak pos check passed (%d%%)" % (completeness * 100 / 9))
        print("Yield (fake) = %.1f" % (completeness / 9))
        self.assertGreaterEqual(completeness, 9)

    @weight(2)
    @number("10.3")
    def test_yield_vcmm0p1(self):
        power = get_instance_power('merged_vcm0.scs', 'sim_result_vcmm0p1/dcOp.dc', 'opamp', 'I20')
        olg = get_gain("sim_result_vcmm0p1/ac.ac", net_input="net062", unit_input="V", net_output="vout1", net_input_diff="net044")
        offset = np.abs(get_value("sim_result_vcmm0p1/dcOp.dc", net="offset"))
        ugf = get_unitfreq("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        pm = get_phasemargin("sim_result_vcmm0p1/ac.ac", net="vout2", net_in="net021")
        _, yosc = get_clipped("sim_result_vcmm0p1/tranPeak.tran.tran", "vout3", 9.6e-6, 1e-5)
        ymax, ymin = max(yosc + .1), min(yosc - .1)

        tsrr, ysrr = get_clipped("sim_result_vcmm0p1/tranSRR.tran.tran", "vout3", 1.98e-6, 2.04e-6)
        slew_rising = get_slew_rate(tsrr, ysrr, -.4, .4, 10, 90)

        tsrf, ysrf = get_clipped("sim_result_vcmm0p1/tranSRF.tran.tran", "vout3", 2.98e-6, 3.04e-6)
        slew_falling = get_slew_rate(tsrf, ysrf, .4, -.4, 10, 90)

        completeness = 0
        if power < 550e-6:
            completeness += 1
            print("Power check passed (%d%%)" % (completeness * 100 / 9))
        if olg > 600:
            completeness += 1
            print("OLG check passed (%d%%)" % (completeness * 100 / 9))
        if np.abs(offset) < 1e-3:
            completeness += 1
            print("offset check passed (%d%%)" % (completeness * 100 / 9))
        if ugf > 100e6:
            completeness += 1
            print("UGF check passed (%d%%)" % (completeness * 100 / 9))
        if pm > 70:
            completeness += 1
            print("PM check passed (%d%%)" % (completeness * 100 / 9))
        if slew_rising > 100e6:
            completeness += 1
            print("Rising slew check passed (%d%%)" % (completeness * 100 / 9))
        if slew_falling < -100e6:
            completeness += 1
            print("Falling slew check passed (%d%%)" % (completeness * 100 / 9))
        if ymax > .5:
            completeness += 1
            print("Vpeak pos check passed (%d%%)" % (completeness * 100 / 9))
        if ymin < -.5:
            completeness += 1
            print("Vpeak pos check passed (%d%%)" % (completeness * 100 / 9))
        print("Yield (fake) = %.1f" % (completeness / 9))
        self.assertGreaterEqual(completeness, 9)
