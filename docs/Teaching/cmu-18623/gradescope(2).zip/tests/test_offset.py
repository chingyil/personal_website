import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display
from util.get_power import get_value

class TestOffset(unittest.TestCase):
    def setUp(self):
        self.input_offset_uV = get_value("sim_result_vcm0/dcOp.dc", net="offset") * 1e6
        self.input_offset_vcm0p1_uV = get_value("sim_result_vcm0p1/dcOp.dc", net="offset") * 1e6
        self.input_offset_vcmm0p1_uV = get_value("sim_result_vcmm0p1/dcOp.dc", net="offset") * 1e6

    @weight(3)
    @number("2.1")
    def test_offset_1m(self):
        """Test offset < 1m"""
        print("Input offset = %.3fuV" % self.input_offset_uV)
        self.assertLessEqual(np.abs(self.input_offset_uV), 1000)

    @weight(3)
    @number("2.2")
    def test_offset_1m_vcm0p1(self):
        """Test offset < 1m (at VCM = 100m)"""
        print("Input offset = %.3fuV" % self.input_offset_vcm0p1_uV)
        self.assertLessEqual(np.abs(self.input_offset_vcm0p1_uV), 1000)

    @weight(3)
    @number("2.3")
    def test_offset_1m_vcmm0p1(self):
        """Test offset < 1m (at VCM = -100m)"""
        print("Input offset = %.3fuV" % self.input_offset_vcmm0p1_uV)
        self.assertLessEqual(np.abs(self.input_offset_vcmm0p1_uV), 1000)

    @weight(1)
    @number("2.4")
    def test_offset_1m_all(self):
        """Calculate average offset"""
        print("Input offset = %.3fuV" % self.input_offset_vcmm0p1_uV)
        offset = np.abs(get_value("sim_result_vcm0/dcOp.dc", net="offset"))
        offset_vcm0p1 = np.abs(get_value("sim_result_vcm0p1/dcOp.dc", net="offset"))
        offset_vcmm0p1 = np.abs(get_value("sim_result_vcmm0p1/dcOp.dc", net="offset"))
        offset_avg = (offset + offset_vcm0p1 + offset_vcmm0p1) / 3
        print("offset_avg = %.3f" % (offset_avg * 1e6))
        self.assertLessEqual(offset_avg, 1e-3)

