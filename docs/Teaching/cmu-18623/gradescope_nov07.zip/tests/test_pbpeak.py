import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_pbpeak(fname, net="out"):

    psf = PSF(fname)

    signal = np.abs(psf.get_signal(net).ordinate)
    signal_lfreq = signal[0]
    passband = signal.max() / signal_lfreq
    passband_db = 20 * np.log10(passband)
    print("Passband peaking = %.3fdB" % passband_db)

    return passband_db

class TestGain(unittest.TestCase):
    def setUp(self):
        self.pbpeak = get_pbpeak('sim_result/dp1_ac.ac')

    @weight(0)
    @number("6.1")
    def test_pbpeak_3dB(self):
        """Test pbpeak < 3dB"""
        self.assertLessEqual(self.pbpeak, 3)

    @weight(2)
    @number("6.2")
    def test_pbpeak_1dB(self):
        """Test pbpeak < 1dB (623 SPEC)"""
        self.assertLessEqual(self.pbpeak, 1)


