import re
import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_resnsnpoly_nseg(fname, device):
    try:
        with open(fname) as f:
            lines = f.readlines()
            idxs_start = [i for i, l in enumerate(lines) if "subckt %s" % device in l]
            idxs_end = [i for i, l in enumerate(lines) if "ends %s" % device in l]
            assert len(idxs_start) == 1 and len(idxs_end) == 1
            idx_start = idxs_start[0]
            idx_end = idxs_end[0]
            nseg = idx_end - idx_start - 2
            return nseg
    except:
        print("Cannot find number of segment, nseg = 1")
        return 1

def interpret_number(s):
    prefix = {"y":1e-24, "z":1e-21, "a":1e-18, "f":1e-15, "p": 1e-12,
          "n":1e-9, "u":1e-6, "µ":1e-6, "m":1e-3, "c":1e-2, "d":0.1,
          "h":100, "k":1000, "M":1e6, "G":1e9, "T":1e12, "P":1e15,
          "E":1e18, "Z":1e21, "Y":1e24}

    assert '=' in s
    wval = float(re.findall('[0-9\.]+', s)[0])
    wscale = re.findall('[nu]', s.split('=')[1])[0]
    return wval * prefix[wscale]

def scs2components(s):
    regex = "[a-zA-Z()\.0-9=_]+[a-zA-Z()\.0-9 =_]*"
    lines_components = re.findall(regex, s.replace("\\\n",""))
    return lines_components

def get_ncomponents(fname):
    with open(fname) as f:
        lines = f.readlines()
        idxs_start = [i for i, l in enumerate(lines) if "subckt TIA BIAS IN OUT VDD VSS" in l]
        idxs_end = [i for i, l in enumerate(lines) if "ends TIA" in l]
        assert len(idxs_start) == 1 and len(idxs_end) == 1
        idx_start = idxs_start[0]
        idx_end = idxs_end[0]
        print(idx_start, idx_end)

        lines_components = scs2components("".join(lines[idx_start + 1:idx_end]))
    return len(lines_components)

def get_area(fname):

    print("Open %s" % fname)
    with open(fname) as f:
        lines = f.readlines()
        idxs_start = [i for i, l in enumerate(lines) if "subckt TIA BIAS IN OUT VDD VSS" in l]
        idxs_end = [i for i, l in enumerate(lines) if "ends TIA" in l]
        assert len(idxs_start) == 1 and len(idxs_end) == 1
        idx_start = idxs_start[0]
        idx_end = idxs_end[0]

        lines_components = scs2components("".join(lines[idx_start + 1:idx_end]))

    area_total = 0
    for l in lines_components:
        tokens = re.findall('[(][a-zA-Z0-9=\s]+[)]|[a-zA-Z0-9=]+[a-zA-Z0-9()\._]*', l)
        device = tokens[2]
        try:
            if device == 'g45n1svt' or device == 'g45p1svt':
                w_str = re.findall('w=[(]*[0-9\.]+[a-zA-Z][)]*', l)[0]
                l_str = re.findall('l=[(]*[0-9\.]+[a-zA-Z][)]*', l)[0]
                w_um = interpret_number(w_str) * 1e6
                l_um = interpret_number(l_str) * 1e6
                area = w_um * (l_um + .28)
                print("Testing a mosfet (%s, %s) (area = %.2f)" % (tokens[0], device, area))
            elif device.split('_')[0] == 'resnsnpoly':
                nseg = get_resnsnpoly_nseg(fname, device)
                w_str = re.findall('segW=[(]*[0-9\.]+[a-zA-Z][)]*', l)[0]
                l_str = re.findall('segL=[(]*[0-9\.]+[a-zA-Z][)]*', l)[0]
                w_um = interpret_number(w_str) * 1e6
                l_um = interpret_number(l_str) * 1e6
                area = w_um * l_um * nseg
                print("Testing a resistor (%s, %s) (area = %.2f)" % (tokens[0], device, area))
            elif device == 'mimcap':
                w_str = re.findall('W=[(]*[0-9\.]+[a-zA-Z][)]*', l)[0]
                l_str = re.findall('L=[(]*[0-9\.]+[a-zA-Z][)]*', l)[0]
                w_um = interpret_number(w_str) * 1e6
                l_um = interpret_number(l_str) * 1e6
                area = w_um * l_um
                print("Testing a capacitor (%s, %s) (area = %.2f)" % (tokens[0], device, area))
            else:
                print("Invalid components %s" % device)
                area = 0
        except:
            print("Something went wrong, area = 0 for %s" % tokens[0])
            area = 0
        area_total += area
    return area_total

class TestArea(unittest.TestCase):
    def setUp(self):
        self.area = get_area('input.scs')

    @weight(10)
    @number("0.1")
    def test_valid_components(self):
        """Test all components are valid"""
        print("Component check bypassed here. We will check by ourselves")
        self.assertGreaterEqual(self.area, 0)
