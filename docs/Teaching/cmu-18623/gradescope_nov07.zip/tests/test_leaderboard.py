# -*- coding: utf-8 -*-

import unittest
import random
from gradescope_utils.autograder_utils.decorators import leaderboard
from test_gain import get_gain
from test_rin import get_rin
from test_bandwidth import get_3dbfreq
from test_power import get_power
from test_area import get_area, get_ncomponents

class TestLeaderboard(unittest.TestCase):
    def setUp(self):
        pass

    @leaderboard("Gain (kohm)")
    def test_leaderboard_gain(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        gain = get_gain("sim_result/dp1_ac.ac") // 1000
        set_leaderboard_value(gain)

    @leaderboard("Rin (ohm)")
    def test_leaderboard_rin(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        rin = get_rin("sim_result/dp1_ac.ac") // 10 * 10
        set_leaderboard_value(rin)

    @leaderboard("BW (MHz)")
    def test_leaderboard_bw(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        bw = get_3dbfreq("sim_result/dp1_ac.ac") // 1e6
        set_leaderboard_value(bw)

    @leaderboard("Power (uW)")
    def test_leaderboard_power(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        power = get_power("sim_result/dp1_dc.dc") // 1e-6
        set_leaderboard_value(power)

    @leaderboard("Area (um2)")
    def test_leaderboard_area(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        area = int(get_area("input.scs"))
        set_leaderboard_value(area)

    @leaderboard("# of components")
    def test_leaderboard_ncomp(self, set_leaderboard_value=None):
        """Sets a leaderboard value"""
        ncomp = get_ncomponents("input.scs")
        set_leaderboard_value(ncomp)

#     @leaderboard("accuracy")
#     def test_leaderboard_float(self, set_leaderboard_value=None):
#         """Sets a leaderboard value"""
#         set_leaderboard_value(round(random.uniform(50, 100), 2))
# 
#     @leaderboard("stars")
#     def test_string(self, set_leaderboard_value=None):
#         """Sets a leaderboard value"""
#         set_leaderboard_value("🌟" * random.randint(0, 10))
# 
#     @leaderboard("time", "asc")
#     def test_another(self, set_leaderboard_value=None):
#         """Sets a leaderboard value that's sorted ascending (lower is better)"""
#         set_leaderboard_value(round(random.gauss(7, 3), 2))
