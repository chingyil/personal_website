import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_power(fname, net_isrc="V0:p", vdd=1):

    psf = PSF(fname)

    itot = np.abs(psf.get_signal("V0:p").ordinate)
    power = vdd * itot
    print("I_total = ", itot)
    print("Power = ", power)

    return power

class TestGain(unittest.TestCase):
    def setUp(self):
        self.power = get_power('sim_result/dp1_dc.dc')

    @weight(2)
    @number("3.1")
    def test_power_1mw(self):
        """Test power < 1mW"""
        self.assertLessEqual(self.power, 1e-3)

    @weight(4)
    @number("3.2")
    def test_power_(self):
        """Test power < 0.75mW (421 SPEC)"""
        self.assertLessEqual(self.power, .75e-3)

    @weight(4)
    @number("3.3")
    def test_power_100k(self):
        """Test power < 0.5mW (623 SPEC)"""
        self.assertLessEqual(self.power, .5e-3)


