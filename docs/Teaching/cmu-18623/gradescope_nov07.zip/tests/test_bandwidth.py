import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_3dbfreq(fname, net="out", nfreq=500):

    psf = PSF(fname)

    freq = psf.get_sweep().abscissa
    freq_detailed = np.logspace(np.log10(min(freq)), np.log10(max(freq)), num=nfreq)

    signal = np.abs(psf.get_signal(net).ordinate)
    signal_lfreq = signal[0]
    signal_detailed = np.interp(freq_detailed, freq, signal)
    freq_3db = freq_detailed[signal_detailed < signal_lfreq * np.sqrt(0.5)][0]
    print("Bandwidth = ", freq_3db)

    return freq_3db

class TestGain(unittest.TestCase):
    def setUp(self):
        self.bw = get_3dbfreq('sim_result/dp1_ac.ac')

    @weight(2)
    @number("2.1")
    def test_bw_20M(self):
        """Test bw > 20M"""
        self.assertGreaterEqual(self.bw, 20e6)

    @weight(4)
    @number("2.2")
    def test_bw_45M(self):
        """Test bw > 45M (421 SPEC)"""
        self.assertGreaterEqual(self.bw, 45e6)

    @weight(4)
    @number("2.3")
    def test_bw_70M(self):
        """Test bw > 70M (623 SPEC)"""
        self.assertGreaterEqual(self.bw, 70e6)


