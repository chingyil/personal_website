import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_swing(fname, net="out"):

    psf = PSF(fname)

    swing = np.ptp(psf.get_signal(net).ordinate)
    print("Swing (%s) = " % net, swing)

    return swing

class TestGain(unittest.TestCase):
    def setUp(self):
        self.swing = get_swing('sim_result/dp1_tran.tran.tran', 'out')

    @weight(3)
    @number("4.1")
    def test_swing_100mV(self):
        """Test swing > 100mV"""
        self.assertGreaterEqual(self.swing, .1)

    @weight(7)
    @number("4.2")
    def test_swing_200mV(self):
        """Test swing > 200mV (623 SPEC)"""
        self.assertGreaterEqual(self.swing, .2)


