import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_rin(fname, net_vin="in", net_iin="I4:sink", unit_iin='A', unit_vin='V'):

    psf = PSF(fname)

    iin_unit = psf.get_signal(net_iin).type.units
    vin_unit = psf.get_signal(net_vin).type.units
    assert iin_unit == unit_iin and vin_unit == unit_vin

    iin = np.abs(psf.get_signal(net_iin).ordinate)
    iin_lfreq = iin[0]
    vin = np.abs(psf.get_signal(net_vin).ordinate)
    vin_lfreq = vin[0]
    rin = vin_lfreq / iin_lfreq
    print("Rin = ", rin)

    return rin

class TestGain(unittest.TestCase):
    def setUp(self):
        self.rin = get_rin('sim_result/dp1_ac.ac')

    @weight(2)
    @number("5.1")
    def test_rin_4k(self):
        """Test rin < 4K"""
        self.assertLessEqual(self.rin, 4000)

    @weight(4)
    @number("5.2")
    def test_rin_50k(self):
        """Test rin < 1K (421 SPEC)"""
        self.assertLessEqual(self.rin, 1000)

    @weight(4)
    @number("5.3")
    def test_rin_250(self):
        """Test rin < 250 (623 SPEC)"""
        self.assertLessEqual(self.rin, 250)


