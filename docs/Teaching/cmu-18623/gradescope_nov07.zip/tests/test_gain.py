import numpy as np
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from psf_utils import PSF
from inform import Error, display

def get_gain(fname, net_input="I4:sink", net_output="out", unit_input='A', unit_output='V'):

    psf = PSF(fname)

    iin_unit = psf.get_signal(net_input).type.units
    vout_unit = psf.get_signal(net_output).type.units
    assert iin_unit == unit_input and vout_unit == unit_output

    iin = np.real(psf.get_signal(net_input).ordinate)
    iin_lfreq = iin[0]
    vout = np.abs(psf.get_signal(net_output).ordinate)
    vout_lfreq = vout[0]
    gain = vout_lfreq / iin_lfreq
    print("Gain = ", gain)

    return gain

class TestGain(unittest.TestCase):
    def setUp(self):
        self.gain = get_gain('sim_result/dp1_ac.ac')

    @weight(2)
    @number("1.1")
    def test_gain_10k(self):
        """Test gain > 10K"""
        self.assertGreaterEqual(self.gain, 10000)

    @weight(4)
    @number("1.2")
    def test_gain_50k(self):
        """Test gain > 50K (421 SPEC)"""
        self.assertGreaterEqual(self.gain, 50000)

    @weight(4)
    @number("1.3")
    def test_gain_100k(self):
        """Test gain > 100K (623 SPEC)"""
        self.assertGreaterEqual(self.gain, 100000)


